import os; exec(open(os.environ['S']+'/harness.py').read())
# A) fabricated success: worker returns finish immediately, no tool run
os.environ.update(FAKE_MODE='fabricate', FAKE_TASKS='2')
d=tempfile.mkdtemp(); b=make(Path(d)/'h'); jid=b.submit('Build a 12-file website and test it'); b.close()
g=b.store.get(jid)
print('[A] job:', g['job']['state'], '| runs:', [(r['state'], json.loads(r['artifacts'])['files']) for r in g['runs']], '| result:', g['runs'][0]['result'][:60])
# B) continuation cannot see previous artifacts
os.environ.update(FAKE_MODE='tool', FAKE_TASKS='1')
d=tempfile.mkdtemp(); b=make(Path(d)/'h'); j1=b.submit('make index.html')
while b.store.get(j1)['job']['state'] not in ('completed','partial','failed'): time.sleep(.05)
r1=b.store.get(j1)['runs'][0]; print('[B] first job:', b.store.get(j1)['job']['state'], 'artifacts', json.loads(r1['artifacts'])['files'])
os.environ['FAKE_MODE']='fabricate'
j2=b.continue_job(j1,'Edit the existing index.html'); b.close()
r2=b.store.get(j2)['runs'][0]
ws2=Path(d)/'h'/'workspaces'/j2/r2['id']
print('[B] continuation job:', b.store.get(j2)['job']['state'], '| new workspace files:', sorted(p.name for p in ws2.iterdir()) if ws2.exists() else 'none', '| prompt mentions index.html:', 'index.html' in r2['prompt'] or 'index.html' in b.store.get(j2)['job']['prompt'])
# C) symlink created inside container kills every later step
os.environ.update(FAKE_MODE='tool', FAKE_TASKS='1', FAKE_DOCKER_SYMLINK='1')
class Two:
    def __init__(s): s.n=0
d=tempfile.mkdtemp(); b=make(Path(d)/'h')
# make the fake model ask for two tool steps: first step creates symlink (fake docker), second step refused
import bro.sandbox as sb
calls={'n':0}
orig=b.provider.host_provider.call
def two_steps(prompt, ws, system='', tools=True):
    if 'Reply ONLY with a JSON object' in prompt or 'Summarize these' in prompt: return orig(prompt, ws, system=system, tools=tools)
    calls['n']+=1
    return json.dumps({'action':'run','argv':['python3','-c','print(1)']}) if calls['n']<=2 else json.dumps({'action':'finish','result':'x'})
b.provider.host_provider.call=two_steps
jid=b.submit('npm-like project'); b.close(); g=b.store.get(jid)
print('[C] job:', g['job']['state'], '| run error:', g['runs'][0]['error'])
os.environ.pop('FAKE_DOCKER_SYMLINK')
# D) worker conversation growth: each tool step returns 12000 Armenian chars
d=tempfile.mkdtemp(); b=make(Path(d)/'h'); steps={'n':0}
def chatty(prompt, ws, system='', tools=True):
    if 'Reply ONLY with a JSON object' in prompt or 'Summarize these' in prompt: return orig2(prompt, ws, system=system, tools=tools)
    steps['n']+=1
    return json.dumps({'action':'run','argv':['python3','-c','print("Ա"*12000)']})
orig2=b.provider.host_provider.call
real=ClaudeCLI(command=S+'/bin/claude')
def wrapped(prompt, ws, system='', tools=True):
    r=chatty(prompt, ws, system, tools)
    real.call(prompt, ws, system=system, tools=False)  # forces real argv-size check through Popen
    return r
b.provider.host_provider.call=wrapped
jid=b.submit('verbose build'); b.close(); g=b.store.get(jid)
print('[D] job:', g['job']['state'], '| steps before failure:', steps['n'], '| run error:', g['runs'][0]['error'])
