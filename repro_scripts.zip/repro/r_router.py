import sys,os; sys.path.insert(0,os.environ['BRO_SRC'])
from bro.skills import SkillLibrary; from bro.router import SkillRouter
lib=SkillLibrary(); r=SkillRouter(lib)
A='agt-p04-r02'  # Systems Architect (primary: software-systems-architecture)
cases=[
 ('Write unit tests for the payment API','testing-quality-engineering'),
 ('Add tests for the parser','testing-quality-engineering'),
 ('Triage this SIEM alert and map it to MITRE ATT&CK','cybersecurity-operations-soc'),
 ('Run a pentest of our web app under signed RoE','offensive-security-pentesting'),
 ('Reconcile the general ledger and prepare the VAT return','accounting-bookkeeping-tax'),
 ('Design salary bands for engineers','hr-compensation-design'),
 ('Plan technician dispatch routes for tomorrow','field-service-dispatch-ops'),
 ('Fix the React router navigation bug','frontend-ux-product-design'),
 ('Schedule support agents for the night shift','workforce-scheduling-wfm'),
 ('Review this NDA','legal-compliance-contracts'),
 ('Build a landing page','frontend-ux-product-design'),
 ('Ստեղծիր կայք','frontend-ux-product-design'),
 ('Ստեղծիր կայքը մեր բաժանորդների համար','frontend-ux-product-design'),
 ('Գրիր թեստեր այս կոդի համար','testing-quality-engineering'),
 ('Թարգմանիր այս տեքստը անգլերեն','language-mastery'),
 ('Պատրաստիր GPON ցանցի խափանման հաշվետվություն','telecom-isp-network-ops'),
 ('Կազմիր պայմանագրի նախագիծ','legal-compliance-contracts'),
 ('Վերլուծիր վաճառքի տվյալները','data-science-analytics'),
 ('Configure VLAN and ONU provisioning for GPON','telecom-isp-network-ops'),
 ('SQL Server migration plan','databases-storage-engineering'),
]
ok=0
for t,exp in cases:
    got=r.route(A,t); hit=exp in got; ok+=hit
    print(('PASS' if hit else 'FAIL'), '|', t, '->', got, '| expected', exp)
print(f'{ok}/{len(cases)} expected skill selected')
# reachability: which skills can be selected by any non-slug natural phrase?
slug_only=[s for s,t in r.tags.items() if len(t)==1]
print('skills whose only route tag is their slug phrase:', len(slug_only), slug_only)
