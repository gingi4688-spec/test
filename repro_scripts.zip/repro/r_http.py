import os,sys,subprocess,tempfile,time,json,socket,http.client
sys.path.insert(0,os.environ['BRO_SRC'])
from pathlib import Path
from bro.core import Store, registry
S=os.environ['S']
root=Path(tempfile.mkdtemp()); tok=root/'t'; tok.write_text('k'*40); tok.chmod(0o600)
home=root/'home'; home.mkdir(mode=0o700)
st=Store(home/'bro.sqlite3'); jid=st.create('seed'); rid=st.add_run(jid,'agt-p04-r02','t','t')
w=home/'workspaces'/jid/rid; w.mkdir(parents=True)
for i in range(250): (w/f'f{i:03d}.txt').write_text(str(i))
sys.path.insert(0,os.environ['BRO_SRC']); from bro.artifacts import manifest
m=manifest(w); st.run_state(rid,'completed',artifacts=json.dumps(m)); st.state(jid,'completed')
print('manifest recorded', len(m['files']), 'of 250 files; truncated=', m['truncated'])
rid2=st.add_run(jid,'agt-p04-r02','t2','t2')  # queued run
s=socket.socket(); s.bind(('127.0.0.1',0)); port=s.getsockname()[1]; s.close()
env=dict(os.environ, BRO_HTTP_TOKEN_FILE=str(tok), BRO_HOME=str(home), BRO_PORT=str(port), PATH=S+'/bin:'+os.environ['PATH'],
         FAKE_AGENTS=json.dumps([a['agent_id'] for a in registry()['worker_registry']]))
p=subprocess.Popen([sys.executable,'-m','bro.server'],cwd=os.environ['BRO_SRC'],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
H={'Authorization':'Bearer '+'k'*40}
def req(method,path,body=None,headers=None,raw_len=None):
    c=http.client.HTTPConnection('127.0.0.1',port,timeout=5); h=dict(H,**(headers or {}))
    if body is not None and raw_len is None: h['Content-Length']=str(len(body))
    if raw_len is not None: h['Content-Length']=raw_len
    try:
        c.request(method,path,body=body,headers=h); r=c.getresponse(); return r.status, r.read()[:120]
    except Exception as e: return 'EXC', type(e).__name__
for _ in range(50):
    try:
        if req('GET','/health')[0]==200: break
    except Exception: pass
    time.sleep(.1)
tests=[
 ('GET','/jobs',None,None,None),
 ('GET','/jobs/'+'0'*16,None,None,None),
 ('GET',f'/jobs/{jid}/runs/{rid}/artifacts/f010.txt',None,None,None),
 ('GET',f'/jobs/{jid}/runs/{rid}/artifacts/f240.txt',None,None,None),
 ('GET',f'/jobs/{jid}/runs/{rid}/artifacts/%2e%2e/%2e%2e/bro.sqlite3',None,None,None),
 ('GET',f'/jobs/{jid}/runs/{rid}/artifacts/%252e%252e%252fx',None,None,None),
 ('GET',f'/jobs/{jid}/runs/{rid2}/artifacts/x',None,None,None),
 ('POST','/jobs',b'[1,2]',None,None),
 ('POST','/jobs',b'{"prompt": 5}',None,None),
 ('POST','/jobs',b'not json',None,None),
 ('POST','/jobs',b'{"prompt":"x"}',None,'abc'),
 ('POST','/jobs',b'{"prompt":"x"}',None,'-5'),
 ('POST','/jobs',b'\xff\xfe',None,None),
 ('POST','/jobs',json.dumps({'prompt':'x'*50001}).encode(),None,None),
 ('POST',f'/jobs/{"1"*16}/continue',b'{}',None,None),
 ('POST',f'/jobs/{jid}/continue',b'{"instructions":7}',None,None),
 ('POST','/jobs',b'{"prompt":"real submit"}',None,None),
 ('GET','/jobs',None,{'Authorization':'Bearer wrong'},None),
 ('GET','/health',None,{'Authorization':''},None),
]
for t in tests: print(t[0],t[1][:60],t[3] or '', t[4] or '','->',req(t[0],t[1],t[2],t[3],t[4]))
time.sleep(2)
st2=Store(home/'bro.sqlite3'); j=[x for x in st2.list() if x['prompt']=='real submit'][0]; g=st2.get(j['id'])
print('submitted job via HTTP ->', g['job']['state'], [ (r['state'], r['error']) for r in g['runs']][:2])
p.terminate(); p.wait(5); err=p.stderr.read().decode()[-400:]; print('server stderr tail:', err.replace('\n',' | ')[:400])
