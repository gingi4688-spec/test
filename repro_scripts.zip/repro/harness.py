import sys, os, json, tempfile, time
sys.path.insert(0, os.environ['BRO_SRC'])
from pathlib import Path
from bro.core import Bro, ClaudeCLI, registry
from bro.sandbox import SandboxClaudeCLI, DockerSandbox, SandboxConfig
S=os.environ['S']
os.environ['FAKE_AGENTS']=json.dumps([a['agent_id'] for a in registry()['worker_registry']])
def make(home, conc=5):
    prov=SandboxClaudeCLI(host_provider=ClaudeCLI(command=S+'/bin/claude'),
        sandbox=DockerSandbox(SandboxConfig(require_rootless=False), docker=S+'/bin/docker'))
    return Bro(home, provider=prov, concurrency=conc)
