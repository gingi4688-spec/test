import os, resource; exec(open(os.environ['S']+'/harness.py').read())
from bro.core import BusyError
def peak(log):
    ev=[]
    for line in open(log):
        pid,t,kind=line.split()[:3]; ev.append((float(t),1 if kind=='start' else -1))
    cur=mx=0
    for _,d in sorted(ev): cur+=d; mx=max(mx,cur)
    return mx, sum(1 for _,d in ev if d==1)
for n in (1,5,10,20,30):
    log=os.environ['S']+f'/out/c{n}.log'; open(log,'w').close()
    os.environ.update(FAKE_MODE='tool', FAKE_TASKS=str(n), FAKE_SLEEP='0.5', FAKE_LOG=log)
    d=tempfile.mkdtemp(); b=make(Path(d)/'h', conc=n); t=time.monotonic(); jid=b.submit(f'{n} tasks'); b.close()
    g=b.store.get(jid); el=time.monotonic()-t
    ok=sum(r['state']=='completed' for r in g['runs']); files=sum(len(json.loads(r['artifacts'] or '{}').get('files',[])) for r in g['runs'])
    pk,calls=peak(log)
    print(f'N={n:2d} job={g["job"]["state"]:9s} runs_ok={ok}/{n} artifacts={files} cli_calls={calls} peak_concurrent_cli={pk} wall={el:.1f}s maxrss={resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss//1024}MB')
# same agent many tasks
os.environ.update(FAKE_SLEEP='0.2'); os.environ['FAKE_AGENTS_SAVE']=os.environ['FAKE_AGENTS']
os.environ['FAKE_AGENTS']=json.dumps(['agt-p06-r02']*10); os.environ['FAKE_TASKS']='10'
d=tempfile.mkdtemp(); b=make(Path(d)/'h', conc=10); jid=b.submit('same agent x10'); b.close(); g=b.store.get(jid)
print('same agent x10 ->', g['job']['state'], len({r['id'] for r in g['runs']}), 'distinct runs')
os.environ['FAKE_AGENTS']=os.environ['FAKE_AGENTS_SAVE']
# queue saturation and job-pool width
os.environ.update(FAKE_MODE='normal', FAKE_TASKS='1', FAKE_SLEEP='1.0', FAKE_LOG=os.environ['S']+'/out/q.log'); open(os.environ['FAKE_LOG'],'w').close()
os.environ['BRO_MAX_PENDING_JOBS']='5'
d=tempfile.mkdtemp(); b=make(Path(d)/'h', conc=5); acc=rej=0
for i in range(8):
    try: b.submit(f'j{i}'); acc+=1
    except BusyError: rej+=1
time.sleep(1.5); states=[x['state'] for x in b.store.list()]
print(f'queue cap=5: accepted={acc} rejected={rej}; states 1.5s later: {sorted(states)}  (only 2 jobs run at once: job pool max_workers=2)')
b.close()
