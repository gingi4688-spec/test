import shutil,subprocess,sys,os,tempfile
SRC=sys.argv[1]
M=[
 ('M1 artifact download ignores run state','bro/server.py',"if run['state'] != 'completed':","if False:"),
 ('M2 HTTP auth disabled','bro/server.py',"if not hmac.compare_digest(provided,'Bearer '+token):","if False:"),
 ('M3 API key not stripped from CLI env','bro/core.py',"for k in ('ANTHROPIC_API_KEY',","for k in ('XX_UNUSED',"),
 ('M4 runs not marked interrupted on restart','bro/core.py',"conn.execute(\"UPDATE runs SET state='interrupted',updated=? WHERE state IN ('queued','running')\",(ts(),))","pass"),
 ('M5 --cap-drop ALL removed','bro/sandbox.py',"'--cap-drop', 'ALL', ",""),
 ('M6 --user removed (container runs as image default user)','bro/sandbox.py',"'--user', f'{os.getuid()}:{os.getgid()}', ",""),
 ('M7 container output leaked into error','bro/sandbox.py',"raise SandboxError(f'sandbox exit {code}; inspect broker-side diagnostics')","raise SandboxError(f'sandbox exit {code}: '+output.decode())"),
 ('M8 job always completed','bro/core.py',"final_state='completed' if all(x['status']=='completed' for x in outcomes) else 'partial'","final_state='completed'"),
 ('M9 final component O_NOFOLLOW removed','bro/artifacts.py',"fd=os.open(parts[-1],os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=handle)","fd=os.open(parts[-1],os.O_RDONLY|os.O_NONBLOCK,dir_fd=handle)"),
 ('M10 --pids-limit removed','bro/sandbox.py',"'--pids-limit', str(self.config.pids), ",""),
 ('M11 tool-step limit raised to 1000','bro/sandbox.py',"MAX_STEPS = 12","MAX_STEPS = 1000"),
 ('M12 FIX of AUD-001 (prompt before --tools)','bro/core.py',"cmd+=['--tools','']  # Never grant Claude CLI direct host tools\n        cmd+=[prompt]","cmd+=['--tools','','--',prompt]"),
 ('M13 summary failure hidden as completed','bro/core.py',"summary=self.provider.call(summary_prompt,self.home/'chief',tools=False)","summary='ok'"),
 ('M14 continuation allowed on active job','bro/core.py',"raise BusyError('cannot continue an active job')","pass"),
]
for name,f,old,new in M:
    d=tempfile.mkdtemp(); w=os.path.join(d,'w'); shutil.copytree(SRC,w)
    p=os.path.join(w,f); t=open(p).read(); assert t.count(old)==1,(name,t.count(old)); open(p,'w').write(t.replace(old,new))
    r=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-q'],cwd=w,capture_output=True,text=True,timeout=300)
    last=[l for l in r.stderr.splitlines() if l.startswith(('OK','FAILED'))]
    hs=subprocess.run([sys.executable,'tools/http_smoke.py'],cwd=w,env=dict(os.environ,PYTHONPATH='.'),capture_output=True,text=True,timeout=60)
    print(f"{name:55s} unittest: {'KILLED' if r.returncode else 'SURVIVED'} ({last[-1] if last else '?'}) | http_smoke: {'KILLED' if hs.returncode else 'survived'}")
    shutil.rmtree(d)
