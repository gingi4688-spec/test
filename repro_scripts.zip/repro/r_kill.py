import os; exec(open(os.environ['S']+'/harness.py').read())
os.environ.update(FAKE_MODE='normal', FAKE_TASKS='3', FAKE_SLEEP='30', FAKE_LOG=os.environ['S']+'/out/kill.log')
b=make(Path(os.environ['HOMEDIR'])); jid=b.submit('slow job'); print('JID',jid,flush=True)
time.sleep(60)
