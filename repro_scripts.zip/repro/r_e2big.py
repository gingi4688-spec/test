import os; exec(open(os.environ['S']+'/harness.py').read())
# 1) single long prompt (Armenian 70k chars -> ~140KB UTF-8) direct CLI call
try:
    ClaudeCLI(command=S+'/bin/claude').call('Ա'*70000, Path(tempfile.mkdtemp())/'c')
    print('long prompt: OK')
except Exception as e: print('long prompt ->', type(e).__name__, e)
# 2) end-to-end: 3 workers each finish with 60KB result -> summary prompt > 128KB
os.environ.update(FAKE_MODE='big', FAKE_TASKS='3')
d=tempfile.mkdtemp(); b=make(Path(d)/'h'); jid=b.submit('Build three docs'); b.close()
g=b.store.get(jid); print('job state:', g['job']['state'], '| error:', g['job']['error'])
print('run states:', [r['state'] for r in g['runs']])
